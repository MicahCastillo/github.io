﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Windows.Forms;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] A = { 1.0, 2.0, 3.0, 5.0 };
            double[] A1 = new double[100];
            double[] B = { 1.0, 2.0, 3.0, 5.0,6.0 };
            double[] B1 = new double[100];
            double C;
            string outputmsg = " ";
            string caption = "system.array methods illustrated";
            int u= 0;
            Array.Copy(A, 0, A1, 0, 4);
            Array.Copy(B, 0, B1, 0, 5);
            foreach (double num in A) ;
            int i = 0;
            int o = 0;
            while (u < B.Length)
            {
                C = A1[i] + B1[o];
                i++;
                o++;
                u++;
                WriteLine(C);
                MessageBox.Show(outputmsg, C);
            }

            Read();
        }
    }
}
