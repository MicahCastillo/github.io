﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ConsoleApplication4
{
    class Test1
    {
        static void Main(string[] args)
        {
            string invalue;
            int[] score = new int[10];
            int div2 = 0;
            int add = 0;
            for (int i = 0; i < score.Length; i++)
            {
                invalue = ReadLine();
                int.TryParse(invalue, out score[i]);
                div2 = score[i] %2;
                if (div2 == 0)
                    WriteLine("yes");
                else
                    WriteLine("No");
                WriteLine("Total: " + div2);
                add = score[i] + score[0];  
                WriteLine("");
                WriteLine(add);
            }

            ReadLine();
        }
    }
}
