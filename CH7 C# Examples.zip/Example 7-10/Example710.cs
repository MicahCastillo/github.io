﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Windows.Forms;

namespace Example_7_10
{
    class Example710
    {
        static void Main(string[] args)
        {
            double[] waterdepth = { 45, 19, 2, 16.8, 190, 0.8, 510, 6, 18 };
            string outputmsg = " ";
            string caption = "system.array methods illustrated";
            double[] w = new double[100];

            // display contents of array water depth
            outputmsg += "waterdepth array\n\n";
            foreach (double wval in waterdepth)
                outputmsg += wval + "\n";

            MessageBox.Show(outputmsg, caption);

            //copy values from waterdepth to w
            //begin at imdex location 2
            //place values in w array, starting at location 0
            //copy 5 values
            Array.Copy(waterdepth, 2, w, 0, 5);

            //sort the values
            Array.Sort(w);
            outputmsg += "array w sorted\n\n";
            foreach (double wval in w)
            {
                if (wval > 0)
                    outputmsg += wval + "\n";
            }
            MessageBox.Show(outputmsg, caption);
            { }
            public static void displayoutput(double[] anArray, string msg)
        {
            foreach (double wval in anArray)
            {
                if (wval > 0)
                    msg += wval + "\n";
            }
        }
    }
}

