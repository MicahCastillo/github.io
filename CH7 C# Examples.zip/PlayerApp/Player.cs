﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayerApp
{
    class Player
    {
        //chpt 7-15
        #region //class field region
        private string lastname;
        private string firstname;
        private string Id;
        private int[] pointsscored;
        private int numberofgames;
        #endregion

        public Player()
        {

        }
        #region
        public Player(string ln,string fn, string id,int[]s,int numgame)
        {
            numberofgames = numgame;
            lastname = ln;
            firstname = fn;
            Id = id;
            FillPointsScoredArray(s);
        }
        public string Fname { get; set; }
        public string LName
        {
            get
            {
                return lastname;
            }
            set
            {
                lastname = value;
            }

        }
        public string ID { get; set; }
        public int NUMofgames { get; set; }
        #endregion
    }
}
