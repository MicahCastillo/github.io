﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace InputEndpointWhile
{
    class InputEndpointWhile
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int startvalue;
            int endvalue;
            string invalue;

            WriteLine("Enter the beggining value");
            invalue = ReadLine();
            if (int.TryParse(invalue, out startvalue) == false)
            {
                WriteLine("invalid input - " + "0 recorder for start value");
                Write("Enter the last value: ");
            }
            invalue = ReadLine();
            if (int.TryParse(invalue, out endvalue) == false)
                WriteLine("invalid input - " + "0 recorder for start value");
            Write("sum of values {0} through {1}", startvalue, endvalue);
            while (startvalue < endvalue + 1)
            {
                sum = sum + startvalue;
                startvalue++;
            }

        }
    }
}
