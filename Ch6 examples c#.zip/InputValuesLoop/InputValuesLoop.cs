﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace InputValuesLoop
{
    class InputValuesLoop
    {
        static void Main(string[] args)
        {
            string invalue = ""; //null value
            Write("this program will let you enter ");
            Write(" value after value. to stop, enter");
            Write("-99");
            while (invalue != "-99")
            {
                Write("\nEnter value(-99 to exit):");
                invalue = ReadLine();
            }
            Read();
        }
    }
}
