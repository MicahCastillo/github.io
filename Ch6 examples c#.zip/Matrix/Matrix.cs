﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Matrix
{
    class Matrix
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            while (true)
            {
                Write(DateTime.Now.ToString("hh:mm:ss"));
                for (int i=0; i < 5; i++)
                {
                    int num = random.Next(0, 26);
                    char let = (char)('a' + num);
                    Write(let);
                }
            }
        }
    }
}
