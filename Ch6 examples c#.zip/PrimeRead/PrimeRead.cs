﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PrimeRead
{
    class PrimeRead
    {
        static void Main(string[] args)
        {
            string invalue="";
            int sum = 0, intvalue;
            Write("this program will let you enter");
            Write(" value after value. to stop, enter");
            WriteLine(" -99");
            Write("\nEnter value (-99 to exit): ");
            invalue = ReadLine(); //priming read
            while (invalue != "-99")
            {
                if (int.TryParse(invalue, out intvalue) == false)
                    WriteLine("invald input-0 stored in" + "intvalue");
                sum += intvalue;
                Write("enter value(-99 to exit: ");
                invalue = ReadLine();
                WriteLine("total values entered {0}", sum);
                Read();
            }

        }
    }
}
