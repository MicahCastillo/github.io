﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace SummedValue
{
    class SummedValue
    {
        static void Main(string[] args)
        {
            int sum=0;
            int number=1;
            while (number < 11)
            {
                sum = sum + number;
                WriteLine("sum is now: " + sum);
                WriteLine("number is now: " + number);
                number++;
            }
            WriteLine("sum of values 1 through 10 is: " + sum);
            Read();
        }
    }
}
