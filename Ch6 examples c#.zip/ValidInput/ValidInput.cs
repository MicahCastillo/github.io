﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ValidInput
{
    class ValidInput
    {
        static void Main(string[] args)
        {
            int intvalue;
            string instringvalue;
            Write("enter an integer value. ");
            instringvalue = ReadLine();
            while (int.TryParse(instringvalue,out intvalue)==false)
            {
                WriteLine("invalid input");
                Write("please re enter an integer value");
                instringvalue = ReadLine();
            }
            WriteLine("valid value entered: " + intvalue);
            Read();
        }
    }
}
