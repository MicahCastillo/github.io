﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace AvgDiff2
{
    class Program
    {
        static void Main(string[] args)
        {
            int total = 0;
            double avg;
            double distance;
            string invalue;
            int[] score = new int[10];
            for (int i = 0; i < score.Length; i++)
            {
                Write("enter score{0}:", i + 1);
                invalue = ReadLine();
                if (int.TryParse(invalue, out score[i]) == false)
                    Write("invalid data entered, 0 stored in array");
            }
            for (int i = 0; i < score.Length; i++)
            {
                total += score[i];
            }
            avg = (double)total / score.Length;
            WriteLine();
            WriteLine("average, {0}", avg.ToString("F2"));
            WriteLine();
            WriteLine("score\tdist. from avg.");
            for (int i = 0; i < score.Length; i++)
            {
                distance = Math.Abs(avg - score[i]);
                WriteLine("{0}\t\t{1}", score[i], distance.ToString("F0"));
            }
            Read();
        }
    }
}
