﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace UnknownSize
{
    class UnknownSize
    {
        static void Main(string[] args)
        {
            int[] score = new int[100];
            string invalue;
            int scorecnt = 0;

            Write("enter score{0}:((-99 to exit))", scorecnt + 1);
            invalue = ReadLine();
            while (invalue != "-99")
            {
                if (int.TryParse(invalue, out score[scorecnt]) == false)
                    WriteLine("invalid data entered-{0} stored in array");
                scorecnt++;
                Write("enter score{0}:((-99 to exit))", scorecnt + 1);
                invalue = ReadLine();
            }

            WriteLine("the number of scores:" + scorecnt);
            Read();


        }
    }
}
