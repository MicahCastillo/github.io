﻿namespace Chapter10ListBox102
{
    partial class ClubForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LstBxEvents = new System.Windows.Forms.ListBox();
            this.TxtBx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Activities = new System.Windows.Forms.Label();
            this.TxtAddActivity = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Label();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LstBxEvents
            // 
            this.LstBxEvents.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LstBxEvents.FormattingEnabled = true;
            this.LstBxEvents.ItemHeight = 20;
            this.LstBxEvents.Items.AddRange(new object[] {
            "dinner",
            "ammusment park",
            "sports event"});
            this.LstBxEvents.Location = new System.Drawing.Point(34, 80);
            this.LstBxEvents.Name = "LstBxEvents";
            this.LstBxEvents.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.LstBxEvents.Size = new System.Drawing.Size(166, 64);
            this.LstBxEvents.TabIndex = 0;
            this.LstBxEvents.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // TxtBx
            // 
            this.TxtBx.Location = new System.Drawing.Point(112, 228);
            this.TxtBx.Name = "TxtBx";
            this.TxtBx.Size = new System.Drawing.Size(183, 21);
            this.TxtBx.TabIndex = 1;
            this.TxtBx.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // Activities
            // 
            this.Activities.AutoSize = true;
            this.Activities.Location = new System.Drawing.Point(31, 63);
            this.Activities.Name = "Activities";
            this.Activities.Size = new System.Drawing.Size(67, 14);
            this.Activities.TabIndex = 3;
            this.Activities.Text = "label2";
            // 
            // TxtAddActivity
            // 
            this.TxtAddActivity.Location = new System.Drawing.Point(314, 80);
            this.TxtAddActivity.Name = "TxtAddActivity";
            this.TxtAddActivity.Size = new System.Drawing.Size(100, 21);
            this.TxtAddActivity.TabIndex = 4;
            // 
            // Add
            // 
            this.Add.AutoSize = true;
            this.Add.Location = new System.Drawing.Point(241, 80);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(67, 14);
            this.Add.TabIndex = 5;
            this.Add.Text = "label3";
            // 
            // BtnAdd
            // 
            this.BtnAdd.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.Location = new System.Drawing.Point(314, 139);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(101, 53);
            this.BtnAdd.TabIndex = 6;
            this.BtnAdd.Text = "AddBtn";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // ClubForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(473, 281);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.TxtAddActivity);
            this.Controls.Add(this.Activities);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtBx);
            this.Controls.Add(this.LstBxEvents);
            this.Font = new System.Drawing.Font("Onky", 8.249999F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Olive;
            this.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.Name = "ClubForm";
            this.Text = "Computer Club Outing Signup";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LstBxEvents;
        private System.Windows.Forms.TextBox TxtBx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Activities;
        private System.Windows.Forms.TextBox TxtAddActivity;
        private System.Windows.Forms.Label Add;
        private System.Windows.Forms.Button BtnAdd;
    }
}

