﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter10ListBox102
{
    public partial class ClubForm : Form
    {
        public ClubForm()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //this.TxtBx.Text=
            //    LstBxEvents.SelectedItem.ToString();
            string result = "";
            foreach(string activity in LstBxEvents.SelectedItems)
            {
                result += activity + " ";
            }
            TxtBx.Text = result;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string newone = TxtAddActivity.Text;
            LstBxEvents.Items.Add(newone);
            //or TxtAddActivity.Text="";
            TxtAddActivity.Clear();
        }
    }
}
