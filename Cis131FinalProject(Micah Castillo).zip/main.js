const electron=require('electron');
//const dialog=require('electron').remote;
//var remote = require('remote'); 
const app=electron.app;
const BrowserWindow=electron.BrowserWindow;

//const {dialog}=require('electron').remote
//var dialog=app.dialog
var fs=require('fs')

const Menu=electron.Menu
const ipc=electron.ipcMain

app.on('ready',function(){
    //console.log('sdfsfdf')
    mainWindow=new BrowserWindow({

    })


    mainWindow.loadURL(`file://${__dirname}/FinalProject.html`);

    const menue=Menu.buildFromTemplate(template);
    Menu.setApplicationMenu(menue);

    mainWindow.on('closed',function(){
        console.log('closed');
        mainWindow=null;
    })
})

const template=[
    {
        label:'File',
        submenu:[
            //{label:'Save File',click:savefile()},
                //app.dialog.showSaveDialog(__filename);
                    //if(__filename===undefined){
                        //alert('you did not enter in a file name')
                        //return;
                    //}
                    //var content=document

                    //fs.writeFile(__filename)
                //})
            //}},
            {label:'Load File'}
        ]
    },{
        label:'Edit',
        submenu:[
            //{label:'Add Item',click:function(){
                //Subwindow=new BrowserWindow({
                   // width:400,
                   // length:400
                //})
                //Subwindow.loadURL(`file://${__dirname}/SubForm.html`);
            //}},
            {label:'Clear Items'},
            {label: 'Quit',
        click:_=>{app.quit()},
        accelerator: 'Ctrl+Q'}
        ]
    },{
        label:'DeveloperTools',click:function(item,focusedWindow){
            focusedWindow.toggleDevTools()
        },accelerator:'Ctrl+I'
    },{
        label:'About',
    }

]
