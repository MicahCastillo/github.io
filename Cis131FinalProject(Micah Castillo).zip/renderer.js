var App=require('electron').remote
var dialog=App.dialog
var fs=require('fs')


document.getElementById('Save').addEventListener('click',savefile)
document.getElementById('Load').addEventListener('click',OpenFile)

function savefile(){
    dialog.showSaveDialog((__filename)=>{

    })
}
function OpenFile(){
    dialog.showOpenDialog((__filename)=>{

    })
}