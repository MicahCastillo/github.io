﻿namespace crabshack
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Inventory = new System.Windows.Forms.ListBox();
            this.CartItems = new System.Windows.Forms.ListBox();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.AddToCart = new System.Windows.Forms.Button();
            this.Calculate = new System.Windows.Forms.Button();
            this.Given = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.totall = new System.Windows.Forms.Label();
            this.tax = new System.Windows.Forms.Label();
            this.subtotal = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Inventory
            // 
            this.Inventory.FormattingEnabled = true;
            this.Inventory.Location = new System.Drawing.Point(46, 48);
            this.Inventory.Name = "Inventory";
            this.Inventory.Size = new System.Drawing.Size(177, 290);
            this.Inventory.TabIndex = 0;
            // 
            // CartItems
            // 
            this.CartItems.FormattingEnabled = true;
            this.CartItems.Location = new System.Drawing.Point(345, 48);
            this.CartItems.Name = "CartItems";
            this.CartItems.Size = new System.Drawing.Size(179, 290);
            this.CartItems.TabIndex = 1;
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(46, 355);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(100, 20);
            this.txtNum.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(345, 355);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            // 
            // AddToCart
            // 
            this.AddToCart.Location = new System.Drawing.Point(162, 353);
            this.AddToCart.Name = "AddToCart";
            this.AddToCart.Size = new System.Drawing.Size(75, 23);
            this.AddToCart.TabIndex = 4;
            this.AddToCart.Text = "button1";
            this.AddToCart.UseVisualStyleBackColor = true;
            this.AddToCart.Click += new System.EventHandler(this.button1_Click);
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(464, 355);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(75, 23);
            this.Calculate.TabIndex = 5;
            this.Calculate.Text = "button2";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Given
            // 
            this.Given.Location = new System.Drawing.Point(232, 516);
            this.Given.Name = "Given";
            this.Given.Size = new System.Drawing.Size(100, 20);
            this.Given.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(174, 523);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "label1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(361, 513);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.totall);
            this.groupBox1.Controls.Add(this.tax);
            this.groupBox1.Controls.Add(this.subtotal);
            this.groupBox1.Location = new System.Drawing.Point(243, 355);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(88, 124);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // totall
            // 
            this.totall.AutoSize = true;
            this.totall.Location = new System.Drawing.Point(14, 81);
            this.totall.Name = "totall";
            this.totall.Size = new System.Drawing.Size(35, 13);
            this.totall.TabIndex = 2;
            this.totall.Text = "label3";
            // 
            // tax
            // 
            this.tax.AutoSize = true;
            this.tax.Location = new System.Drawing.Point(14, 59);
            this.tax.Name = "tax";
            this.tax.Size = new System.Drawing.Size(35, 13);
            this.tax.TabIndex = 1;
            this.tax.Text = "label2";
            // 
            // subtotal
            // 
            this.subtotal.AutoSize = true;
            this.subtotal.Location = new System.Drawing.Point(14, 28);
            this.subtotal.Name = "subtotal";
            this.subtotal.Size = new System.Drawing.Size(44, 13);
            this.subtotal.TabIndex = 0;
            this.subtotal.Text = "subtotal";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 562);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Given);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.AddToCart);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.CartItems);
            this.Controls.Add(this.Inventory);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Inventory;
        private System.Windows.Forms.ListBox CartItems;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button AddToCart;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.TextBox Given;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label subtotal;
        private System.Windows.Forms.Label totall;
        private System.Windows.Forms.Label tax;
    }
}

