﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace crabshack
{
    public partial class Form1 : Form
    {
        //instance global variables
        Krusty[] kitems = new Krusty[10];
        Krusty[] kcart = new Krusty[10];

        int lastcartitem = 0;
        decimal totalamountdue;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //put class data into the array entries
            kitems[0] = new Krusty(1010, "Tasty Crab", 15, 24.99m);
            kitems[1] = new Krusty(1020, "Lobster", 16, 35.99m);

            //add the array items to our listbox
            Inventory.Items.Add(kitems[0]);
            Inventory.Items.Add(kitems[1]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int index = Inventory.SelectedIndex;
                int numwanted = Convert.ToInt32(txtNum.Text);
                if (kitems[index].Qty < numwanted)
                    MessageBox.Show("amount requested not available");
                else
                    UpdateInventory(index, numwanted);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error");
            }
        }
        private void UpdateInventory(int index,int numwanted)
        {
            int itemNo;
            string productName;
            int qty;
            decimal price;

            kitems[index].Qty = kitems[index].Qty - numwanted;
            itemNo = kitems[index].ItemNo;
            productName = kitems[index].ProductName;
            price = kitems[index].Price;

            for (int i = 0; i < numwanted; i++)
            {
                kcart[lastcartitem] = new Krusty(itemNo, productName, numwanted, price);
                CartItems.Items.Add(kcart[lastcartitem]);
                lastcartitem++;
            }
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            decimal temp;
            temp = Krusty.CalculateSubTotal(kcart);
            subtotal.Text = temp.ToString("C");

            temp = Krusty.CalculateTax(kcart);
            tax.Text = temp.ToString("C");

            temp = Krusty.CalculateTotal(kcart);
            totall.Text = temp.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                decimal amountgiven, change;
                string msg;
                amountgiven = Convert.ToInt32(Given.Text);
                change = amountgiven - totalamountdue;
                msg = string.Format("change due= {0:C}", change);
                MessageBox.Show(msg, "krusty");
            }
            catch (Exception)
            {
                MessageBox.Show("invalid input");
            }
        }
    }
}
