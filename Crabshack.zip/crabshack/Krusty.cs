﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace crabshack
{
    class Krusty
    {
        #region local class variable - private
        private int itemNo;
        private string productName;
        private int qty;
        private decimal price;
        #endregion
        #region
        public int ItemNo
        {
            get
            {
                return itemNo;
            }
            set
            {
                itemNo = value;
            }
        }
        public string ProductName
        {
            get
            {
                return productName;
            }
            set
            {
                productName = value;
            }
        }
        public int Qty
        {
            get
            {
                return qty;
            }
            set
            {
                qty = value;
            }
        }
        public decimal Price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }
        #endregion
        #region
        public Krusty(int itemNo,string productName,int qty,decimal price)
        {
            this.itemNo = itemNo;
            this.productName = productName;
            this.qty = qty;
            this.price = price;
        }
        #endregion
        #region
        public override string ToString()
        {
            return itemNo + "\t" + productName + "\t" + price.ToString("C");
        }
        #endregion
        public static decimal CalculateSubTotal(Krusty[] items)
        {
            decimal subTotal = 0;
            foreach(Krusty item in items)
            {
                if (item is Krusty)
                    subTotal += item.Price;
            }
            return subTotal;
        }
        public static decimal CalculateTax(Krusty[] items)
        {
            decimal Tax = 0;
            foreach (Krusty item in items)
            {
                if (item is Krusty)
                    Tax += (item.Price*.075m);
            }
            return Tax;
        }
        public static decimal CalculateTotal(Krusty[] items)
        {
            decimal total = 0;
            foreach (Krusty item in items)
            {
                if (item is Krusty)
                    total += (item.Price*.075m)+item.price;
            }
            return total;
        }
    }
}
