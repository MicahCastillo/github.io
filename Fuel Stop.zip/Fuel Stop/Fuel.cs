﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fuel_Stop
{
    class Fuel
    {
        private const double LinG = 3.78;
        private double gallonC = 0;
        private double literC = 0;
        private double totalcpl;

        public double GallonC
        {
            get { return gallonC; }
            set { gallonC = value; }
        }
        public double LiterC
        {
            get { return literC; }
            set { literC = value; }
        }
        public Fuel(double ugallonC,double uliterC)
        {
            gallonC = ugallonC;
            literC = uliterC;
        }
        public double Totalcpl()
        {
            totalcpl = LinG * literC;
            return totalcpl;
        }
        public string IF()
        {
            if (Totalcpl() > gallonC)
            {
                return "Buy from the American station!\n" +
                    "	Canadian liter converted to price per gallon: " + totalcpl.ToString("C");
            }
            else
            {
                return "h";
            }
        }
        public override string ToString()
        {
            return  IF() + "\n";
        }
    }
}
