﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Fuel_Stop
{
    class FuelStopApp
    {
        static void Main(string[] args)
        {
            double cpg = 0;
            double cpl = 0;
            Strings();
            cpg = getCPLandCPG("American Station", "Price per gallon");
            cpl = getCPLandCPG("Canadian Station", "Price per liter");
            Fuel fuel = new Fuel(cpg,cpl);
            Spaces();
            Write(fuel);
            Read();
        }
        static void Strings()
        {
            WriteLine("Which gas station should be used?");
            WriteLine("");
            WriteLine("The first value entered is price per liter at the Canadian station.");
            WriteLine("The second value entered is the price per gallon at the American station.");
            WriteLine("");
            WriteLine("A decision is made as to which station offers the most economical fuel price.");
            WriteLine("Please enter the price per Canadian liter: Please enter the price per American gallon: ");
            WriteLine(" Which station has the best fuel prices?");
            WriteLine("");
        }
        static void Spaces()
        {
            WriteLine("");
            WriteLine("");
        }
        static double getCPLandCPG(string station,string price)
        {

            string input;
            double cplcpg=0;
            input = ReadLine();
            double.TryParse(input, out cplcpg);
            WriteLine("{0} - {1}: {2}", station,price,cplcpg.ToString("C"));
            return cplcpg;

        }
    }
}
