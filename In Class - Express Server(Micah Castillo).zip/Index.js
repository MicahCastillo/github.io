

//Micah Castillo
//11/8/2017
//WebDev 2

var express = require('express');
var app = express();
var path= require('path');
 
app.get('/Index', function (req, res) {res.sendFile(path.join(__dirname + '/Index.html'));});

app.get('/About', function (req, res) {res.sendFile(path.join(__dirname + '/About.html'));});

app.listen(3000);
console.log('--Server up--');