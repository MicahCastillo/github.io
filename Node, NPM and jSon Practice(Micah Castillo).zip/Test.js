
/* Micah Castillo
11/6/2017
Node, NPM and jSon Practice */

var ld = require('lodash')
var fs = require('fs');
var json=JSON.parse(fs.readFileSync('data.json','utf-8'));
var len=json['items'].length;
for(var i=0;i<len;i++)
{
    var fnm = (json['items'][i]['fname']);
    var lnm = (json['items'][i]['lname']);
    var age = (json['items'][i]['age']);

    //console.log(json['items'][i]['fname']);
    //console.log(json['items'][i]['lname']);
    //console.log(json['items'][i]['age']);

    console.log(`First Name: ${fnm} \n Last Name: ${lnm} \n  Age: ${age} \n` );
}