﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkClassApp
{
    class ParkClass
    {
        private string parkname;
        private string location;
        private string parktype;
        private string facility;
        private double fee;
        private string employeenumber;
        private int visitorsrecorded;
        private double budget;
        private double revenue;
        private double costpervist;

        public string Parkname
        {
            get
            {
                return parkname;
            }
            set
            {
                parkname = value;
            }
        }
        public string Location
        {
            get
            {
                return location;
            }
            set
            {
                location = value;
            }
        }
        public string Parktype
        {
            get
            {
                return parktype;
            }
            set
            {
                parktype = value;
            }
        }
        public string Facility
        {
            get
            {
                return facility;
            }
            set
            {
                facility = value;
            }
        }
        public double Fee
        {
            get
            {
                return fee;
            }
            set
            {
                fee = value;
            }
        }
        public string Employeenumber
        {
            get
            {
                return employeenumber;
            }
            set
            {
                employeenumber = value;
            }
        }
        public int Visitorsrecorded
        {
            get
            {
                return visitorsrecorded;
            }
            set
            {
                visitorsrecorded = value;
            }
        }
        public double Budget
        {
            get
            {
                return budget;
            }
            set
            {
                budget = value;
            }
        }
        public double Revenue2
        {
            get
            {
                return revenue;
            }
            set
            {
                revenue = value;
            }
        }
        public double Costpervist2
        {
            get
            {
                return costpervist;
            }
            set
            {
                costpervist = value;
            }
        }
        public double Revenue()
        {
            revenue = fee * visitorsrecorded;
            return revenue;
        }
        public double Costpervist()
        {
            costpervist = budget / visitorsrecorded;
            return costpervist;
        }
        public ParkClass(string uparkname, string ulocation, string uparktype,string ufacility,double ufee,string uemployeenumber,int uvisitorsrecorded,double ubudget)
        {
            parkname = uparkname;
            location = ulocation;
            parktype = uparktype;
            facility = ufacility;
            fee = ufee;
            employeenumber = uemployeenumber;
            visitorsrecorded = uvisitorsrecorded;
            budget = ubudget;
        }

        public override string ToString()
        {
            return "Park: " + parkname +
                   "\nPark Location: " + location +
                   "\nType of Park: " + parktype +
                   "\nFacilities Available: " + facility +
                   "\nEntrance Fee: " + fee +
                   "\nNumber of Employees: " + employeenumber +
                   "\nNumber of Visitors Last Year: " + visitorsrecorded +
                   "\nAnnual Budget: " + budget +
                   "\nRevenue From Fees: " + Revenue() +
                   "\nCost Per Visitor: " + Costpervist();
        }
    }
    class ParkClass2
    {
        private string parkname;
        private string location;
        private string facility;

        public string Parkname
        {
            get
            {
                return parkname;
            }
            set
            {
                parkname = value;
            }
        }
        public string Location
        {
            get
            {
                return location;
            }
            set
            {
                location = value;
            }
        }
        public string Facility
        {
            get
            {
                return facility;
            }
            set
            {
                facility = value;
            }
        }
        public ParkClass2(string uparkname,string ulocation,string ufacility)
        {
            parkname = uparkname;
            location = ulocation;
            facility = ufacility;
        }
        public override string ToString()
        {
            return "Park: " + parkname +
                   "\nPark Location: " + location +
                   "\nFacilities Available: " + facility;
        }
    }
    class ParkClass3
    {
        private string parkname;
        private string location;
        private string parktype;

        public string Parkname
        {
            get
            {
                return parkname;
            }
            set
            {
                parkname = value;
            }
        }
        public string Location
        {
            get
            {
                return location;
            }
            set
            {
                location = value;
            }
        }
        public string Parktype
        {
            get
            {
                return parktype;
            }
            set
            {
                parktype = value;
            }
        }
        public ParkClass3(string uparkname,string ulocation,string uparktype)
        {
            parkname = uparkname;
            location = ulocation;
            parktype = uparktype;
        }
        public override string ToString()
        {
            return "Park: " + parkname +
                   "\nPark Location: " + location +
                   "\nType of Park: " + parktype;
        }
    }
}