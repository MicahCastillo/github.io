﻿using static System.Console;

namespace ParkClassApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ParkClass yulie = new ParkClass("Yulie", "Wyoming", "National", "camping", 5.00, "500", 100000, 750000.00);
            WriteLine(yulie);
            ParkClass2 huegonot = new ParkClass2("Heugonot", "Kerry GA","3.00");
            huegonot.Facility = "Hiking, Biking, Camping";
            Write("\n\n");
            WriteLine(huegonot);
            ParkClass3 Aster = new ParkClass3("", "", "");
            Aster.Parkname = "Aster Regional Park";
            Aster.Location = "Maine";
            Aster.Parktype = "Local";
            Write("\n\n");
            WriteLine(Aster);
            Read();
        }
    }
}
