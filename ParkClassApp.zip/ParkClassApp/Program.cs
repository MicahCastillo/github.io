﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ParkClassApp
{
    class Program
    {
        static void Main(string[] args)
        {
            park1 = new ParkClass;
            WriteLine(park1);
            Read();
        }
    }
}
