﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ParkClassApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ParkClass park1 = new ParkClass("Yulie", "Wyoming", "National", "camping", 5.00, "500", 100000, 750000.00);
            WriteLine(park1);
            Read();
        }
    }
}
