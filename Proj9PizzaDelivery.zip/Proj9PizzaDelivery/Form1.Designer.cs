﻿namespace Proj9PizzaDelivery
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.CrustTypeBox = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SauceTypeBox = new System.Windows.Forms.ListBox();
            this.ToppingsBox = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.DrinkBox = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DrinkSizeBox = new System.Windows.Forms.GroupBox();
            this.SmallSize = new System.Windows.Forms.RadioButton();
            this.MediumSize = new System.Windows.Forms.RadioButton();
            this.LargeSize = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.OrderPage = new System.Windows.Forms.TabPage();
            this.First = new System.Windows.Forms.TextBox();
            this.Mid = new System.Windows.Forms.TextBox();
            this.Last = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SS = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.OrderBtn = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.DrinkSizeBox.SuspendLayout();
            this.OrderPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.OrderPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(469, 467);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.ToppingsBox);
            this.tabPage1.Controls.Add(this.SauceTypeBox);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.CrustTypeBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(461, 441);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pizza";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // CrustTypeBox
            // 
            this.CrustTypeBox.FormattingEnabled = true;
            this.CrustTypeBox.Items.AddRange(new object[] {
            "Thick Crust",
            "Thin Crust",
            "Hand Tossed",
            "Foot Tossed",
            "Not Tossed"});
            this.CrustTypeBox.Location = new System.Drawing.Point(8, 53);
            this.CrustTypeBox.Name = "CrustTypeBox";
            this.CrustTypeBox.Size = new System.Drawing.Size(120, 69);
            this.CrustTypeBox.TabIndex = 0;
            this.CrustTypeBox.SelectedIndexChanged += new System.EventHandler(this.CrustTypes_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.DrinkSizeBox);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.DrinkBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(461, 441);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Drinks";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Crust Types";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Sauce Types";
            // 
            // SauceTypeBox
            // 
            this.SauceTypeBox.FormattingEnabled = true;
            this.SauceTypeBox.Items.AddRange(new object[] {
            "Pizza Sauce",
            "Tomato Pesto",
            "Cheese Sauce",
            "No Sauce"});
            this.SauceTypeBox.Location = new System.Drawing.Point(8, 175);
            this.SauceTypeBox.Name = "SauceTypeBox";
            this.SauceTypeBox.Size = new System.Drawing.Size(120, 56);
            this.SauceTypeBox.TabIndex = 3;
            // 
            // ToppingsBox
            // 
            this.ToppingsBox.FormattingEnabled = true;
            this.ToppingsBox.Items.AddRange(new object[] {
            "Pepperoni",
            "Sausage",
            "White Onion",
            "Green Ogion",
            "Red Onion",
            "Mushroom",
            "Bacon",
            "Beef",
            "Left Beef",
            "Tomatos",
            "Feta",
            "Garlic",
            "Carrots",
            "Black Olvies"});
            this.ToppingsBox.Location = new System.Drawing.Point(287, 53);
            this.ToppingsBox.Name = "ToppingsBox";
            this.ToppingsBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.ToppingsBox.Size = new System.Drawing.Size(120, 186);
            this.ToppingsBox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(284, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Toppings";
            // 
            // DrinkBox
            // 
            this.DrinkBox.FormattingEnabled = true;
            this.DrinkBox.Items.AddRange(new object[] {
            "Dr Coke",
            "Mr Pepper",
            "Mountain Pepsi",
            "Muntser",
            "Water"});
            this.DrinkBox.Location = new System.Drawing.Point(30, 206);
            this.DrinkBox.Name = "DrinkBox";
            this.DrinkBox.Size = new System.Drawing.Size(120, 69);
            this.DrinkBox.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Drinks";
            // 
            // DrinkSizeBox
            // 
            this.DrinkSizeBox.Controls.Add(this.LargeSize);
            this.DrinkSizeBox.Controls.Add(this.MediumSize);
            this.DrinkSizeBox.Controls.Add(this.SmallSize);
            this.DrinkSizeBox.Location = new System.Drawing.Point(30, 48);
            this.DrinkSizeBox.Name = "DrinkSizeBox";
            this.DrinkSizeBox.Size = new System.Drawing.Size(97, 90);
            this.DrinkSizeBox.TabIndex = 2;
            this.DrinkSizeBox.TabStop = false;
            // 
            // SmallSize
            // 
            this.SmallSize.AutoSize = true;
            this.SmallSize.Location = new System.Drawing.Point(6, 19);
            this.SmallSize.Name = "SmallSize";
            this.SmallSize.Size = new System.Drawing.Size(50, 17);
            this.SmallSize.TabIndex = 0;
            this.SmallSize.TabStop = true;
            this.SmallSize.Text = "Small";
            this.SmallSize.UseVisualStyleBackColor = true;
            // 
            // MediumSize
            // 
            this.MediumSize.AutoSize = true;
            this.MediumSize.Location = new System.Drawing.Point(5, 42);
            this.MediumSize.Name = "MediumSize";
            this.MediumSize.Size = new System.Drawing.Size(62, 17);
            this.MediumSize.TabIndex = 1;
            this.MediumSize.TabStop = true;
            this.MediumSize.Text = "Medium";
            this.MediumSize.UseVisualStyleBackColor = true;
            // 
            // LargeSize
            // 
            this.LargeSize.AutoSize = true;
            this.LargeSize.Location = new System.Drawing.Point(5, 65);
            this.LargeSize.Name = "LargeSize";
            this.LargeSize.Size = new System.Drawing.Size(52, 17);
            this.LargeSize.TabIndex = 2;
            this.LargeSize.TabStop = true;
            this.LargeSize.Text = "Large";
            this.LargeSize.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Drink Sizes";
            // 
            // OrderPage
            // 
            this.OrderPage.Controls.Add(this.OrderBtn);
            this.OrderPage.Controls.Add(this.label12);
            this.OrderPage.Controls.Add(this.SS);
            this.OrderPage.Controls.Add(this.label11);
            this.OrderPage.Controls.Add(this.label10);
            this.OrderPage.Controls.Add(this.Email);
            this.OrderPage.Controls.Add(this.Phone);
            this.OrderPage.Controls.Add(this.label9);
            this.OrderPage.Controls.Add(this.label8);
            this.OrderPage.Controls.Add(this.label7);
            this.OrderPage.Controls.Add(this.label6);
            this.OrderPage.Controls.Add(this.Last);
            this.OrderPage.Controls.Add(this.Mid);
            this.OrderPage.Controls.Add(this.First);
            this.OrderPage.Location = new System.Drawing.Point(4, 22);
            this.OrderPage.Name = "OrderPage";
            this.OrderPage.Padding = new System.Windows.Forms.Padding(3);
            this.OrderPage.Size = new System.Drawing.Size(461, 441);
            this.OrderPage.TabIndex = 2;
            this.OrderPage.Text = "Order Page";
            this.OrderPage.UseVisualStyleBackColor = true;
            // 
            // First
            // 
            this.First.Location = new System.Drawing.Point(21, 76);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(100, 20);
            this.First.TabIndex = 0;
            // 
            // Mid
            // 
            this.Mid.Location = new System.Drawing.Point(172, 76);
            this.Mid.Name = "Mid";
            this.Mid.Size = new System.Drawing.Size(100, 20);
            this.Mid.TabIndex = 1;
            // 
            // Last
            // 
            this.Last.Location = new System.Drawing.Point(317, 76);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(100, 20);
            this.Last.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Fisrt Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(193, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Middle Initial";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(339, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Last Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(113, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(240, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "To finish your order, please fill in the boxes below.\r\n";
            // 
            // Phone
            // 
            this.Phone.Location = new System.Drawing.Point(89, 153);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(100, 20);
            this.Phone.TabIndex = 7;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(253, 153);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(100, 20);
            this.Email.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(99, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Phone Number";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(288, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Email";
            // 
            // SS
            // 
            this.SS.Location = new System.Drawing.Point(172, 215);
            this.SS.Name = "SS";
            this.SS.Size = new System.Drawing.Size(100, 20);
            this.SS.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(181, 199);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Social Security";
            // 
            // OrderBtn
            // 
            this.OrderBtn.Location = new System.Drawing.Point(131, 307);
            this.OrderBtn.Name = "OrderBtn";
            this.OrderBtn.Size = new System.Drawing.Size(189, 77);
            this.OrderBtn.TabIndex = 13;
            this.OrderBtn.Text = "Place Order";
            this.OrderBtn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 467);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "(Placeholder pizza title)";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.DrinkSizeBox.ResumeLayout(false);
            this.DrinkSizeBox.PerformLayout();
            this.OrderPage.ResumeLayout(false);
            this.OrderPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox CrustTypeBox;
        private System.Windows.Forms.ListBox SauceTypeBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox ToppingsBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox DrinkBox;
        private System.Windows.Forms.GroupBox DrinkSizeBox;
        private System.Windows.Forms.RadioButton LargeSize;
        private System.Windows.Forms.RadioButton MediumSize;
        private System.Windows.Forms.RadioButton SmallSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage OrderPage;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Last;
        private System.Windows.Forms.TextBox Mid;
        private System.Windows.Forms.TextBox First;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Phone;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox SS;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button OrderBtn;
    }
}

