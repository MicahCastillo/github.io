﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj10FileStreams
{
    class Items
    {
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public int ID { get; set; }
        public string Class { get; set; }
        public string Grade { get; set; }

        public Items(string Firstname,string Lastname,int ID,string Class,string Grade)
        {
            this.Firstname = Firstname;
            this.Lastname = Lastname;
            this.ID = ID;
            this.Class = Class;
            this.Grade = Grade;
        }
        public override string ToString()
        {
            return string.Format("{1},{0}: {2} {3} {4}", Firstname, Lastname, ID, Class, Grade);
        }
    }
}
