var http = require('http')
var url = require('url')
var fs = require('fs')

http.createServer(function(req,res){
    var pathname =url.parse(req.url).pathname;
    console.log(pathname);

    switch(pathname){
        case '/D':
            theFile='jsExample2.html';
            break;
        case '/S':
            theFile = 'anonFunction1.html';
            break;
    }

    fs.readFile(theFile,function(err,data){
        res.writeHead('200',{
            'Content-text' : 'text/html'
        });
        res.end(data);

    });

    /* if(pathname==="/"){
        res.writeHead('200',{
        'Content-type':'text/plain'
        //307 'Location' : 'http://w3schools.com'
    });
        res.end('index.html');
    }else{
        res.writeHead('404',{
            'Conent-type' : 'text/plain'
        });
        res.end('file not found')
    } */
    
}).listen(3000)//portnumber;

console.log('--Server UP--');

//Terminal
//-----------
//(node 'FileName'.'FileType')
//node index.js

//(127.0.0.1:'portnumber')
//127.0.0.1:3000

//(127.0.0.1:'portnumber')/FileName
//127.0.0.1:3000