﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ch4_ex_104_student
{
    class StudentTesterApp
    {
        static void Main(string[] args)
        {
            student firststudentobject = new student();
            //firststudentobject.Studentfirstname = askforstudentname("first");
            string stuname = askforstudentname("first");
            string stuname2 = askforstudentname("second");
            string First = stuname;
            string last = stuname2;
            string stuidnum = askforstudentnumber();
            string major = askformajor(stuname,stuname2);
            int score1 = askforexamscore(1);
            int score2 = askforexamscore(2);
            int score3 = askforexamscore(3);



            firststudentobject.Studentfirstname = stuname;
            firststudentobject.Studentlastname= stuname2;
            firststudentobject.SID = stuidnum;
            firststudentobject.Major = major;
            firststudentobject.Score1=




            Console.Read();
        }// end of main
        /// <summary>
        /// prompt for exam score
        /// </summary>
        /// <param name="whichone"></param>
        /// <returns></returns>
        static int askforexamscore(int whichone)
        {
            string invalue;
            int ascore;
            Console.Write("enter a value for score{0}:", whichone);
            invalue = Console.ReadLine();
            ascore = int.Parse(invalue);
            return ascore;

        }// end of method
        /// <summary>
        /// prompt for student name
        /// </summary>
        /// <param name="whichone"></param>
        /// <returns></returns>
        static string askforstudentname(string whichone)
        {
            string invalue;
            Console.Write("Enter studern {0} name:", whichone);
            invalue = Console.ReadLine();
            return invalue;
        }//end of method
        static string askformajor(string First ,string last)
        {
            string invalue;
            Console.Write("Enter {0} {1}\'s Major " ,First, last);
            invalue = Console.ReadLine();
            return invalue;
        }//end method
        static string askforstudentnumber()
        {
            string invalue;
            Console.Write("Enter student number: ");
            invalue = Console.ReadLine();
            return invalue;
        }//end of method
    }
}
