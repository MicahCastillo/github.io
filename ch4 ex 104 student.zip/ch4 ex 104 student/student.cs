﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ch4_ex_104_student
{
    public class student
    {
        private string major;
        private int score1;
        private int score2;
        private int score3;
        private string studentfirstname;
        private string studentlastname;
        private string studentnumber;

        public student()
        {

        }
        
        /// <summary>
        /// construct a student with a student number
        /// </summary>
        /// <param name="sid"></param>
        public student(string sid)
        {
            studentnumber = sid;
        }
        
        /// <summary>
        /// construct a student with three parameters
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="lastname"></param>
        /// <param name="firstname"></param>
        public student(string sid, string lastname, string firstname)
        {
            studentnumber = sid;
            studentfirstname = firstname;
            studentlastname = lastname;
        }

        /// <summary>
        /// construct a student with all parameters
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="lastname"></param>
        /// <param name="firstname"></param>
        /// <param name="s1"></param>
        /// <param name="s2"></param>
        /// <param name="s3"></param>
        /// <param name="maj"></param>
        public student(string sid, string lastname, string firstname, int s1, int s2, int s3, string maj)
        {
            studentnumber = sid;
            studentfirstname = firstname;
            studentlastname = lastname;
            score1 = s1;
            score2 = s2;
            score3 = s3;
            major = maj;
        }
        public string SID
        {
            get
            {
                return studentnumber;
            }
            set
            {
                studentnumber = value;
            }
        }
        public string Studentfirstname
        {
            get
            {
                return studentfirstname;
            }
            set
            {
                studentfirstname = value;
            }
        }
        public string Studentlastname
        {
            get
            {
                return studentlastname;
            }
            set
            {
                studentlastname = value;
            }
        }
        public int Score1
        {
            get
            {
                return score1;
            }
            set
            {
                score1 = value;
            }
        }
        public int Score2
        {
            get
            {
                return score2;
            }
            set
            {
                score2 = value;
            }
        }
        public int Score3
        {
            get
            {
                return score3;
            }
            set
            {
                score3 = value;
            }
        }
        public string Major
        {
            get
            {
                return major;
            }
            set
            {
                major = value;
            }
        }
        public override string ToString()
        {
            return "firstname" + studentfirstname +
                    "Lastname" + studentlastname +
                    "student number" + studentnumber +
                    "score1" + score1 +
                    "score2" + score2 +
                    "score3" + Score3 +
                    "majore" + major;
        }
    }
}
