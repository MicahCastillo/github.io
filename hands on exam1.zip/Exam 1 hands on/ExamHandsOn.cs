﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_1_hands_on
{
    class ExamHandsOn
    {
        private string destination;
        private double distancetraveled;
        private double totalcostofgasoline;
        private double numberofgalonsconsumed;

        public string Destination
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public double Distancetraveled
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public double Totalcostofgasoline
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public double Numberofgalonsconsumed
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public double MilesPerGalon()
        {
            throw new System.NotImplementedException();
        }

        public double CostPerMile()
        {
            throw new System.NotImplementedException();
        }

        public override string ToString()
        {
            throw new System.NotImplementedException();
        }
    }
}
